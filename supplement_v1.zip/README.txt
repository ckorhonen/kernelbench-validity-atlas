Supplement for 'A held-out validation protocol for shape-generalization claims in kernel dispatch' (thermodynamic_mind, 2026-10-20).
Repo state: rstation/kernelbench commit c02e6b3.
results/ = run outputs (one JSON per experiment; the paper cites these exactly).
scripts/ = harnesses, each with the timestamped preregistration docstring at its head.
The frozen guard rule (threshold, features, corpus sha256) is embedded in results/guard_v1.json and results/b4_guard_v1.json 'freeze' blocks.
